//
//  Canada.swift
//  Assignment
//
//  Created by kathiravan Raju on 12/08/19.
//  Copyright © 2019 kathiravan Raju. All rights reserved.
//

import Foundation

public func dataFromApi(_ Api: String) -> Data? {
    @objc class TestClass: NSObject { }
    
    //    let bundle = Bundle(for: TestClass.self)
    //    if let path = bundle.path(forResource: filename, ofType: "json") {
    //        return try? Data(contentsOf: URL(fileURLWithPath: path))
    //    }
    return nil
}

