//
//  CustomTableViewCell.swift
//  Assignment
//
//  Created by kathiravan Raju on 12/08/19.
//  Copyright © 2019 kathiravan Raju. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    var namelbl = UILabel()
    var desclbl = UILabel()
    var userImage = UIImageView()
    
    
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        // configure titleLabel
        contentView.addSubview(userImage)
        contentView.addSubview(namelbl)
        contentView.addSubview(desclbl)
        
        userImage.translatesAutoresizingMaskIntoConstraints = false
        namelbl.translatesAutoresizingMaskIntoConstraints = false
        desclbl.translatesAutoresizingMaskIntoConstraints = false
        
        userImage.leftAnchor.constraint(equalTo:contentView.leftAnchor, constant: 12).isActive = true
        userImage.heightAnchor.constraint(equalToConstant: 50).isActive = true
        userImage.widthAnchor.constraint(equalToConstant: 50).isActive = true
        userImage.centerYAnchor.constraint(equalTo:contentView.centerYAnchor).isActive = true
        
        
        namelbl.topAnchor.constraint(equalTo: contentView.topAnchor,constant: 12).isActive = true
        namelbl.leftAnchor.constraint(equalTo:userImage.rightAnchor, constant: 8).isActive = true
        namelbl.rightAnchor.constraint(equalTo:contentView.rightAnchor, constant: -8).isActive = true
        namelbl.numberOfLines = 0
        namelbl.font = UIFont(name: "AvenirNext-DemiBold", size: 16)

       
        desclbl.topAnchor.constraint(equalTo: namelbl.bottomAnchor, constant: 8).isActive = true
         desclbl.leftAnchor.constraint(equalTo: userImage.rightAnchor, constant: 8).isActive = true
        desclbl.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -8).isActive = true
        desclbl.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12).isActive = true
        desclbl.numberOfLines = 0
        desclbl.font = UIFont(name: "Avenir-Book", size: 18)
        desclbl.textColor = UIColor.lightGray
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
   
//    lazy var backView: UIView = {
//        let view = UIView(frame: CGRect(x: 10, y: 6, width:self.frame.width - 0.5, height: 60))
//        view.backgroundColor = UIColor.white
//        return view
//    }()
//
//    lazy var userImage : UIImageView = {
//        let userImage = UIImageView(frame: CGRect(x: 4, y: 29, width: 80, height: 80   ))
//      //  leftpadding centery
//        userImage.contentMode = .scaleAspectFill
//        return userImage
//    }()
//
//    lazy var namelbl : UILabel = {
//        let lbl = UILabel(frame: CGRect(x: 116, y: 8, width: backView.frame.width - 116, height: 20))
//       // top rightpadding height0
//        lbl.textAlignment = .left
//        lbl.font = UIFont.boldSystemFont(ofSize: 18)
//        return lbl
//    }()
//
//
//
//    lazy var desclbl : UILabel = {
//        let lbl = UILabel(frame: CGRect(x: 116, y: 29, width:backView.frame.width - 116 , height: 20))
//        lbl.textAlignment = .left
//        return lbl
//    }()
//
//
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
//    override func layoutSubviews() {
//        contentView.backgroundColor = UIColor.clear
//        backgroundColor = UIColor.clear
//        backView.layer.cornerRadius = 5
//        backView.clipsToBounds = true
//    }
    
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//        addSubview(backView)
//        backView.addSubview(userImage)
//        backView.addSubview(namelbl)
//        backView.addSubview(desclbl)
    


//        userImage.anchor(top: topAnchor, left: leftAnchor, bottom: bottomAnchor, right: nil, paddingTop: 5, paddingLeft: 5, paddingBottom: 5, paddingRight: 0, width: 90, height: 40, enableInsets: false)
//        namelbl.anchor(top: topAnchor, left: userImage.rightAnchor, bottom: nil, right: nil, paddingTop: 20, paddingLeft: 10, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
//        desclbl.anchor(top: namelbl.topAnchor, left: userImage.rightAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 10, paddingBottom: 30, paddingRight: 5, width: frame.size.width / 2, height: 0, enableInsets: false)
//        desclbl.numberOfLines = 0

    
//    }
    
   
    
    
}
